CREATE DATABASE company_user_db;
